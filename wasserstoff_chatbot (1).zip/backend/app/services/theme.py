import openai
from app.services.qa import get_answers

openai.api_key = "your-openai-key"

def synthesize_themes(query, top_k=5):
    results = get_answers(query, top_k)
    context = "\n\n".join([f"[DocID: {r['doc_id']}, Page: {r['page']}]\n{r['text']}" for r in results])
    prompt = f"""
You are a legal/technical summarizer bot. A user asked: "{query}"

Given the following document excerpts, extract the major themes or insights, and summarize them as bullet points.
Group similar ideas and cite supporting DocIDs and Page numbers.

Documents:
{context}
"""
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.4,
    )
    return response.choices[0].message.content.strip()