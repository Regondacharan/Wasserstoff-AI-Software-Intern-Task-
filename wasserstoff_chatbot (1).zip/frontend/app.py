import streamlit as st
import requests

st.title("📚 Wasserstoff Gen-AI Research Chatbot")

st.header("Upload Document")
uploaded_file = st.file_uploader("Upload PDF", type=["pdf"])
doc_date = st.date_input("Document Date")
doc_author = st.text_input("Author")
doc_type = st.selectbox("Document Type", ["Legal", "Policy", "Technical", "Other"])

if uploaded_file:
    files = {"file": uploaded_file}
    metadata = {"date": str(doc_date), "author": doc_author, "type": doc_type}
    response = requests.post("http://localhost:8000/upload/", files=files, data=metadata)
    st.success("Document uploaded and processed!")

st.header("Ask a Question")
query = st.text_input("Type your question here")
if query:
    res = requests.post("http://localhost:8000/query/", json={"query": query})
    for answer in res.json()["results"]:
        with st.expander(f"{answer['doc_id']} - Page {answer['page']}"):
            st.write(answer['text'])

    theme_res = requests.post("http://localhost:8000/themes/", json={"query": query})
    st.subheader("Synthesized Theme")
    st.write(theme_res.json()["summary"])