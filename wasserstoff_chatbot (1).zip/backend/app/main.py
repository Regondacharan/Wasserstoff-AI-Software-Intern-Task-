from fastapi import FastAPI, UploadFile, File, Body
from app.services.pdf_handler import process_document
from app.services.qa import get_answers
from app.services.theme import synthesize_themes

app = FastAPI()

@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    text_chunks = await process_document(file)
    return {"chunks": text_chunks}

@app.post("/query/")
async def query_docs(query: str = Body(...)):
    results = get_answers(query)
    return {"results": results}

@app.post("/themes/")
async def themes(query: str = Body(...)):
    summary = synthesize_themes(query)
    return {"summary": summary}