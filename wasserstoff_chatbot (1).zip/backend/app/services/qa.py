from sentence_transformers import SentenceTransformer
import chromadb

model = SentenceTransformer("all-MiniLM-L6-v2")
chroma_client = chromadb.Client()
collection = chroma_client.get_or_create_collection("docs")

def get_answers(query, top_k=5):
    query_embedding = model.encode(query).tolist()
    results = collection.query(query_embeddings=[query_embedding], n_results=top_k)
    answers = []
    for doc, meta in zip(results["documents"][0], results["metadatas"][0]):
        answers.append({"doc_id": meta["doc_id"], "page": meta["page"], "text": doc})
    return answers